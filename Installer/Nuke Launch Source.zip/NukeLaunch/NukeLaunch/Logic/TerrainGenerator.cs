﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace NukeLaunch.Logic {
	public class TerrainGenerator {
		#region Class variables
		private const float MIN_HEIGHT = 250f;
		private const float MAX_WIDTH = 1100f;
		#endregion Class variables

		#region Class propeties

		#endregion Class properties

		#region Constructor

		#endregion Constructor

		#region Support methods
		public Texture2D generate() {
			Texture2D terrain = null;

			return terrain;
		}
		#endregion Support methods

		#region Destructor

		#endregion Destructor
	}
}
